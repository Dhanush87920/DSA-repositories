# https://github.com/mntejesh/Tejesh/tree/main
This repo is of many C program and all kind of Python programs.
## Index  
[ least_count in c language](least_count.c)  
[least count](least_count.py)  
[sorting technique](sorting.py)  
[linked_list](linked_list.py)  
[Linked list using stack](Linked_stack.py)  
[Binary search Tree](BST.py)  
[Sorting Algorithms](Sorting.py)  
[Binary_Tree](Binary_Tree.py)
