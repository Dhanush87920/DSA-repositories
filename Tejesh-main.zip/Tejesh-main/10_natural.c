#include <stdio.h>
int main()
{
           int i, sum = 0;
          // Calculate sum of 10 natural numbers
          for (i = 1; i <= 10; i++)
          {
              sum += i;
           }
              printf("Sum of 10 natural numbers: %d\n", sum);
              return 0;
}
