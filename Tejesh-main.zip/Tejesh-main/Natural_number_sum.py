n = int(input("Enter a number: "))

sum_n = n * (n + 1) // 2

print(f"The sum of natural numbers up to {n} is: {sum_n}")
