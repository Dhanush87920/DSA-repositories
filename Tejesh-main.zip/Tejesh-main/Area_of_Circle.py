radius = int(input())

AREA = 3.14*(radius**2)

print("Area of the circle:",AREA)

print("Area of the circle:",AREA,sep="")

print(f"Area of the circle: {AREA}")


print("Area of the circle:",AREA)

