#include <stdio.h>
             int main() {
             int a = 9, b = 13, c = 3;
            float x, y, z;
            x = a - b / 3.0 + c * 2 - 1;
            y = a - (float)b / (3 + c) * (2 - 1);
            z = a - ((float)b / (3 + c) * 2) - 1;
            printf("x = %.2f\n", x);
           printf("y = %.2f\n", y);
           printf("z = %.2f\n", z);
           return 0;
}

        printf("Number is not divisible by both 5 and 11.\n");
    }
return 0;
}
